
import os
import asyncio
from datetime import datetime, timedelta, timezone
from typing import List, Dict, Any, Optional

import jwt
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.hash import bcrypt

from .mikrotik import get_api
from .db import get_conn, init_db, insert_traffic_log, query_traffic, upsert_client_seen

# --- App & CORS ---
app = FastAPI(title="MikroTik Dashboard API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Auth via JWT ---
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")
APP_USER = os.getenv("APP_USER", "admin")
APP_PASS = os.getenv("APP_PASS", "ChangeMe123!")
APP_JWT_SECRET = os.getenv("APP_JWT_SECRET", "devsecret")
APP_JWT_EXPIRE_MINUTES = int(os.getenv("APP_JWT_EXPIRE_MINUTES", "43200"))  # default 30 days

PASSWORD_HASH = bcrypt.hash(APP_PASS)


def create_access_token(subject: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=APP_JWT_EXPIRE_MINUTES)
    payload = {"sub": subject, "exp": expire}
    token = jwt.encode(payload, APP_JWT_SECRET, algorithm="HS256")
    return token


def verify_token(token: str) -> str:
    try:
        payload = jwt.decode(token, APP_JWT_SECRET, algorithms=["HS256"])
        return payload.get("sub")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token expired")
    except Exception:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")


def auth(token: str = Depends(oauth2_scheme)):
    username = verify_token(token)
    if not username:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return username


@app.on_event("startup")
def on_startup():
    init_db()
    # start poller
    asyncio.create_task(poller())


@app.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    if form_data.username != APP_USER or not bcrypt.verify(form_data.password, PASSWORD_HASH):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(form_data.username)
    return {"access_token": token, "token_type": "bearer"}


@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat() + "Z"}


@app.get("/clients", dependencies=[Depends(auth)])
def clients() -> List[Dict[str, Any]]:
    api, pool = get_api()
    try:
        dhcp = api.get_resource('/ip/dhcp-server/lease')
        leases = dhcp.get()
        arp_list = api.get_resource('/ip/arp').get()
        online_macs = set([x.get('mac-address', '').upper() for x in arp_list if x.get('mac-address')])
        data = []
        for l in leases:
            mac = (l.get('mac-address') or '').upper()
            ip = l.get('address')
            hostname = l.get('host-name') or l.get('comment')
            status = 'online' if mac in online_macs else 'offline'
            last_seen = l.get('last-seen')
            data.append({
                'mac': mac,
                'ip': ip,
                'hostname': hostname,
                'status': status,
                'last_seen': last_seen,
            })
            if mac:
                upsert_client_seen(mac=mac, ip=ip, hostname=hostname)
        return data
    finally:
        pool.disconnect()


@app.get("/speed", dependencies=[Depends(auth)])
def speed(interface: Optional[str] = None):
    api, pool = get_api()
    try:
        iface = interface or os.getenv("MT_INTERFACE", "ether1")
        monitor = api.get_resource('/interface/monitor-traffic')
        res = monitor.call('monitor-traffic', {'interface': iface, 'once': 'true'})
        r = res[0] if isinstance(res, list) and res else {}
        return {
            "interface": iface,
            "rx_bps": int(r.get('rx-bits-per-second', 0)),
            "tx_bps": int(r.get('tx-bits-per-second', 0)),
            "time": datetime.utcnow().isoformat() + "Z",
        }
    finally:
        pool.disconnect()


@app.get("/usage/traffic", dependencies=[Depends(auth)])
def usage_traffic(interface: Optional[str] = None, start: Optional[str] = None, end: Optional[str] = None):
    """Returns time-series traffic from SQLite logs filtered by interface and date range (ISO8601)."""
    rows = query_traffic(interface=interface, start=start, end=end)
    return rows


async def poller():
    """Background task to periodically poll traffic and store into SQLite for fail-safe data."""
    interval = max(2, int(os.getenv('POLL_INTERVAL_SECONDS', '5')))
    interfaces = [s.strip() for s in os.getenv('MT_INTERFACE', 'ether1').split(',') if s.strip()]
    while True:
        try:
            api, pool = get_api()
            try:
                monitor = api.get_resource('/interface/monitor-traffic')
                for iface in interfaces:
                    try:
                        res = monitor.call('monitor-traffic', {'interface': iface, 'once': 'true'})
                        r = res[0] if isinstance(res, list) and res else {}
                        rx = int(r.get('rx-bits-per-second', 0))
                        tx = int(r.get('tx-bits-per-second', 0))
                        insert_traffic_log(interface=iface, rx_bps=rx, tx_bps=tx)
                    except Exception:
                        # continue other interfaces even if one fails
                        pass
            finally:
                pool.disconnect()
        except Exception:
            # swallow errors to keep poller alive
            pass
        await asyncio.sleep(interval)
