
import os
from routeros_api import RouterOsApiPool

def get_api():
    host = os.getenv("MT_HOST", "192.168.88.1")
    user = os.getenv("MT_USER", "admin")
    password = os.getenv("MT_PASS", "")
    port = int(os.getenv("MT_PORT", "8728"))
    use_ssl = os.getenv("MT_SSL", "false").lower() == "true"

    pool = RouterOsApiPool(
        host=host,
        username=user,
        password=password,
        port=port,
        plaintext_login=not use_ssl,
        use_ssl=use_ssl,
    )
    return pool.get_api(), pool
