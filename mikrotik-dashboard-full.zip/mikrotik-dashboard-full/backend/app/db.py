import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

DB_PATH = Path('/data/mikrotik.db')


def get_conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS clients (
          mac TEXT PRIMARY KEY,
          ip TEXT,
          hostname TEXT,
          first_seen TEXT,
          last_seen TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS traffic_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts TEXT,
          interface TEXT,
          rx_bps INTEGER,
          tx_bps INTEGER
        )
    """)
    conn.commit()
    conn.close()


def upsert_client_seen(mac: str, ip: Optional[str], hostname: Optional[str]):
    now = datetime.utcnow().isoformat() + 'Z'
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO clients (mac, ip, hostname, first_seen, last_seen)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(mac) DO UPDATE SET ip=excluded.ip, hostname=excluded.hostname, last_seen=excluded.last_seen
        """,
        (mac, ip, hostname, now, now),
    )
    conn.commit()
    conn.close()


def insert_traffic_log(interface: str, rx_bps: int, tx_bps: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO traffic_logs (ts, interface, rx_bps, tx_bps) VALUES (?, ?, ?, ?)',
        (datetime.utcnow().isoformat() + 'Z', interface, rx_bps, tx_bps),
    )
    conn.commit()
    conn.close()


def query_traffic(interface: Optional[str], start: Optional[str], end: Optional[str]) -> List[Dict[str, Any]]:
    q = 'SELECT ts, interface, rx_bps, tx_bps FROM traffic_logs WHERE 1=1'
    params = []
    if interface:
        q += ' AND interface = ?'
        params.append(interface)
    if start:
        q += ' AND ts >= ?'
        params.append(start)
    if end:
        q += ' AND ts <= ?'
        params.append(end)
    q += ' ORDER BY ts ASC'

    conn = get_conn()
    cur = conn.cursor()
    cur.execute(q, params)
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return rows
