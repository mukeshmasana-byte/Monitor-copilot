#!/bin/sh
# Render nginx config with env vars
envsubst < /etc/nginx/templates/default.conf.template > /etc/nginx/conf.d/default.conf
exec nginx -g 'daemon off;'
