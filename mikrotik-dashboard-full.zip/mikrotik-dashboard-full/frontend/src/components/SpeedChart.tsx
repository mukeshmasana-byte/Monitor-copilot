import React from 'react'
import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

interface Row { ts: string; rx_bps: number; tx_bps: number }

const SpeedChart: React.FC<{ data: Row[] }> = ({ data }) => {
  const labels = data.map(d => new Date(d.ts).toLocaleTimeString())
  const chartData = {
    labels,
    datasets: [
      { label: 'RX (bps)', data: data.map(d => d.rx_bps), borderColor: 'rgb(54, 162, 235)', tension: 0.3 },
      { label: 'TX (bps)', data: data.map(d => d.tx_bps), borderColor: 'rgb(255, 99, 132)', tension: 0.3 },
    ]
  }
  const options = { responsive: true, maintainAspectRatio: false }
  return <div style={{height: 300}}><Line data={chartData} options={options} /></div>
}

export default SpeedChart
