import React from 'react'

type Row = { mac: string; ip?: string; hostname?: string; status: string; last_seen?: string }

const ClientsTable: React.FC<{ rows: Row[] }> = ({ rows }) => {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Status</th>
            <th>MAC</th>
            <th>IP</th>
            <th>Hostname</th>
            <th>Last seen</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r.mac + i}>
              <td>
                <span className={r.status === 'online' ? 'pill online' : 'pill offline'}>{r.status}</span>
              </td>
              <td>{r.mac}</td>
              <td>{r.ip || ''}</td>
              <td>{r.hostname || ''}</td>
              <td>{r.last_seen || ''}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default ClientsTable
