import React, { useState } from 'react'
import './styles.css'

const Login: React.FC = () => {
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      const form = new FormData()
      form.append('username', username)
      form.append('password', password)
      form.append('grant_type', 'password')
      const res = await fetch((import.meta.env.VITE_API_BASE || '/api') + '/token', {
        method: 'POST',
        body: form
      })
      if (!res.ok) throw new Error('Login failed')
      const data = await res.json()
      localStorage.setItem('token', data.access_token)
      window.location.href = '/'
    } catch (err: any) {
      setError(err.message || 'Login failed')
    }
  }

  return (
    <div className="container">
      <form className="card" onSubmit={submit}>
        <h2>MikroTik Dashboard Login</h2>
        {error && <div className="error">{error}</div>}
        <label>Username</label>
        <input value={username} onChange={e => setUsername(e.target.value)} />
        <label>Password</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
        <button type="submit">Login</button>
      </form>
    </div>
  )
}

export default Login
