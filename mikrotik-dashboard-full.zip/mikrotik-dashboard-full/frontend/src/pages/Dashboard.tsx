import React, { useEffect, useMemo, useState } from 'react'
import api from '../api'
import SpeedChart from '../components/SpeedChart'
import ClientsTable from '../components/ClientsTable'

interface TrafficRow { ts: string; interface: string; rx_bps: number; tx_bps: number }

const Dashboard: React.FC = () => {
  const [iface, setIface] = useState<string>('ether1')
  const [traffic, setTraffic] = useState<TrafficRow[]>([])
  const [clients, setClients] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [rangeStart, setRangeStart] = useState('')
  const [rangeEnd, setRangeEnd] = useState('')

  const load = async () => {
    setLoading(true)
    try {
      const [t, c] = await Promise.all([
        api.get('/usage/traffic', { params: { interface: iface, start: rangeStart || undefined, end: rangeEnd || undefined } }),
        api.get('/clients')
      ])
      setTraffic(t.data)
      setClients(c.data)
    } finally { setLoading(false) }
  }

  useEffect(() => { load(); const id = setInterval(load, 5000); return () => clearInterval(id) }, [iface, rangeStart, rangeEnd])

  const latestSpeed = useMemo(() => traffic.length ? traffic[traffic.length - 1] : undefined, [traffic])

  const logout = () => { localStorage.removeItem('token'); window.location.href = '/login' }

  return (
    <div className="page">
      <header>
        <h1>MikroTik Dashboard</h1>
        <div className="spacer" />
        <button onClick={logout}>Logout</button>
      </header>

      <section className="controls">
        <label>Interface</label>
        <input value={iface} onChange={e => setIface(e.target.value)} placeholder="ether1,wlan1" />
        <label>Start (ISO)</label>
        <input value={rangeStart} onChange={e => setRangeStart(e.target.value)} placeholder="2026-01-01T00:00:00Z" />
        <label>End (ISO)</label>
        <input value={rangeEnd} onChange={e => setRangeEnd(e.target.value)} placeholder="2026-01-31T23:59:59Z" />
        <button onClick={load} disabled={loading}>Refresh</button>
      </section>

      <section className="grid">
        <div className="card">
          <h3>Live Speed</h3>
          <SpeedChart data={traffic} />
          {latestSpeed && (
            <div className="kpis">
              <div><strong>RX:</strong> {(latestSpeed.rx_bps/1e6).toFixed(2)} Mbps</div>
              <div><strong>TX:</strong> {(latestSpeed.tx_bps/1e6).toFixed(2)} Mbps</div>
            </div>
          )}
        </div>
        <div className="card">
          <h3>Clients</h3>
          <ClientsTable rows={clients} />
        </div>
      </section>
    </div>
  )
}

export default Dashboard
