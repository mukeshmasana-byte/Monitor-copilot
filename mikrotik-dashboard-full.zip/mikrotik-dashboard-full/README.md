
# MikroTik Dashboard (Backend + React Frontend)

A full Dockerized web dashboard to monitor your **MikroTik hAP ax³** (and other RouterOS devices):

- ✅ Online/offline clients (MAC/IP/hostname)
- ✅ Live upload/download speed (per interface)
- ✅ Date-range traffic history (fail-safe logging to SQLite)
- ✅ Secure login (JWT)
- ✅ React + Vite frontend
- ✅ Docker images for backend & frontend (built by GitHub Actions)
- ✅ Nginx serving SPA & proxying `/api` to backend

> **Security**: Do **not** commit real router passwords. Use environment variables / GitHub Secrets.

---

## 1) RouterOS prerequisites
Enable the RouterOS API service:

```bash
/ip service enable api
/ip service set api port=8728
```

Create a **read-only API user** (recommended):

```bash
/user group add name=api-read policy=read,api,!write,!sensitive
/user add name=api-user group=api-read password=Strong#Password
```

Use `MT_USER=api-user` + its password in your environment.

---

## 2) Local development (Docker Compose)

Create `.env` at the repository root by copying `.env.example` from `backend/` and filling values.

```bash
cp backend/.env.example .env
```

Then:

```bash
docker compose up --build
```

Open: <http://localhost:8080>

---

## 3) GitHub Actions (build & push images)

### Docker Hub
- Add repo **Secrets**: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`
- Push to `main` → builds and pushes:
  - `${DOCKERHUB_USERNAME}/mikrotik-backend`
  - `${DOCKERHUB_USERNAME}/mikrotik-frontend`

### GHCR
- Add repo **Secrets**: `GHCR_TOKEN` (PAT with `write:packages`)
- Push to `main` → builds and pushes:
  - `ghcr.io/<owner>/mikrotik-backend`
  - `ghcr.io/<owner>/mikrotik-frontend`

---

## 4) Backend API

- `POST /token` (OAuth2 password) → `{ access_token }`
- `GET /clients` (Bearer)
- `GET /speed?interface=ether1` (Bearer)
- `GET /usage/traffic?interface=ether1&start=ISO&end=ISO` (Bearer)

**Headers**: `Authorization: Bearer <token>`

---

## 5) Frontend env vars

- `VITE_API_BASE` (default `/api` for Nginx proxy)
- Container env `BACKEND_ORIGIN` (default `http://backend:8000`), used by Nginx to proxy `/api`.

---

## 6) Production tips

- Put the frontend behind HTTPS (e.g., Cloudflare, Traefik, Caddy).
- Configure firewall to allow API access to RouterOS only from your backend host.
- Rotate the JWT secret and passwords regularly.
- For heavy historical data, switch from SQLite to Postgres.

---

## 7) Credits
- FastAPI
- routeros_api
- React + Vite
- Nginx

